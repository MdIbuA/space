import { useQuery } from "@tanstack/react-query";
import { Container } from "@/components/ui/container";
import { CountdownTimer } from "@/components/countdown-timer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Rocket, Star, Calendar, Globe } from "lucide-react";
import { format } from "date-fns";
import type { Booking } from "@shared/schema";
import { VIPMembership } from "@/components/vip-membership";
import { AstronautSimulator } from "@/components/astronaut-simulator";
import { VRLaunchExperience } from "@/components/vr-launch-experience";

const AI_TRAVEL_TIPS = [
  "Remember to complete your zero-gravity training before departure",
  "Pack light - most items can be synthesized on board",
  "Stay hydrated during your journey with our special space-grade water",
  "Don't forget to document your Earth view from the observation deck"
];

export default function Dashboard() {
  // In a real app, userId would come from auth context
  const userId = 1;

  const { data: bookings, isLoading } = useQuery<Booking[]>({
    queryKey: [`/api/users/${userId}/bookings`],
  });

  if (isLoading) {
    return (
      <Container className="py-12">
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <div
              key={i}
              className="h-32 bg-black/40 animate-pulse rounded-lg"
            />
          ))}
        </div>
      </Container>
    );
  }

  return (
    <div className="min-h-screen bg-[url('https://images.unsplash.com/photo-1728679729521-b35334b00c29')] bg-cover bg-fixed">
      <div className="min-h-screen bg-black/60 backdrop-blur-sm py-12">
        <Container>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <h1 className="text-4xl font-bold text-primary mb-6">
                  Space Travel Dashboard
                </h1>

                <div className="space-y-6">
                  {bookings?.map((booking) => (
                    <Card
                      key={booking.id}
                      className="bg-black/40 backdrop-blur-sm border-primary/20"
                    >
                      <CardHeader className="flex flex-row items-center justify-between">
                        <CardTitle className="text-xl text-primary">
                          Booking #{booking.id}
                        </CardTitle>
                        <Badge
                          variant={
                            booking.status === "confirmed"
                              ? "default"
                              : booking.status === "pending"
                              ? "secondary"
                              : "destructive"
                          }
                        >
                          {booking.status}
                        </Badge>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 gap-4 mb-4">
                          <div>
                            <p className="text-sm text-muted-foreground">
                              Passengers
                            </p>
                            <p className="text-lg font-medium">
                              {booking.passengers}
                            </p>
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">
                              Total Price
                            </p>
                            <p className="text-lg font-medium">
                              ${booking.totalPrice.toLocaleString()}
                            </p>
                          </div>
                        </div>
                        <CountdownTimer
                          targetDate={new Date(booking.bookedAt)}
                        />
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </motion.div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Stats */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 }}
              >
                <Card className="bg-black/40 backdrop-blur-sm border-primary/20">
                  <CardHeader>
                    <CardTitle className="text-primary">Journey Stats</CardTitle>
                  </CardHeader>
                  <CardContent className="grid grid-cols-2 gap-4">
                    <div className="flex items-center gap-2">
                      <Rocket className="h-4 w-4 text-primary" />
                      <span>{bookings?.length || 0} Trips</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Star className="h-4 w-4 text-primary" />
                      <span>VIP Status</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-primary" />
                      <span>Next Launch</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Globe className="h-4 w-4 text-primary" />
                      <span>Dubai Base</span>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              {/* AI Travel Tips */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 }}
              >
                <Card className="bg-black/40 backdrop-blur-sm border-primary/20">
                  <CardHeader>
                    <CardTitle className="text-primary">AI Travel Tips</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-[200px]">
                      <ul className="space-y-4">
                        {AI_TRAVEL_TIPS.map((tip, index) => (
                          <li
                            key={index}
                            className="flex items-start gap-2 text-sm"
                          >
                            <Star className="h-4 w-4 text-primary shrink-0" />
                            <span>{tip}</span>
                          </li>
                        ))}
                      </ul>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </motion.div>

              {/* VIP Membership Section */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.6 }}
              >
                <VIPMembership />
              </motion.div>

              {/* Astronaut Training Simulator */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.8 }}
              >
                <AstronautSimulator />
              </motion.div>

              {/* VR Launch Experience */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 1.0 }}
              >
                <VRLaunchExperience />
              </motion.div>
            </div>
          </div>
        </Container>
      </div>
    </div>
  );
}