import { useState, useEffect } from "react";
import { motion, useAnimation } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Trip } from "@shared/schema";

interface HolographicPreviewProps {
  trip: Trip;
}

export function HolographicPreview({ trip }: HolographicPreviewProps) {
  const [isHovering, setIsHovering] = useState(false);
  const controls = useAnimation();

  useEffect(() => {
    controls.start({
      rotateY: [0, 360],
      transition: {
        duration: 20,
        repeat: Infinity,
        ease: "linear"
      }
    });
  }, []);

  return (
    <div className="relative w-full h-[400px] perspective-1000">
      <motion.div
        animate={controls}
        className="w-full h-full preserve-3d"
        onHoverStart={() => setIsHovering(true)}
        onHoverEnd={() => setIsHovering(false)}
      >
        <Card className={`
          absolute inset-0 
          bg-black/40 backdrop-blur-sm border-primary/20
          ${isHovering ? 'hover-glow' : ''}
          transform-style-preserve-3d
          before:content-['']
          before:absolute before:inset-0
          before:bg-gradient-to-r before:from-primary/20 before:via-transparent before:to-primary/20
          before:animate-[hologram_2s_ease-in-out_infinite]
        `}>
          <div className="relative h-full">
            <img
              src={trip.imageUrl}
              alt={trip.destination}
              className="absolute inset-0 w-full h-full object-cover opacity-80"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
            
            <div className="absolute inset-0 flex flex-col justify-end p-6 text-white">
              <div className="space-y-4">
                <h3 className="text-2xl font-bold text-primary glow">
                  {trip.destination}
                </h3>
                <p className="text-sm text-white/80">{trip.description}</p>
                {trip.descriptionAr && (
                  <p className="text-sm text-white/80 text-right" dir="rtl">
                    {trip.descriptionAr}
                  </p>
                )}
              </div>
            </div>

            <div className="absolute top-4 right-4 flex items-center gap-2">
              <div className="h-2 w-2 bg-primary rounded-full animate-pulse" />
              <span className="text-xs text-primary">LIVE PREVIEW</span>
            </div>
          </div>
        </Card>
      </motion.div>
    </div>
  );
}
