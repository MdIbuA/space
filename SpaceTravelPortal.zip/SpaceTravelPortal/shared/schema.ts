import { pgTable, text, serial, integer, timestamp, jsonb, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  language: text("language").default("en"),
  vipStatus: text("vip_status").default("standard"), // standard, gold, platinum
});

export const trips = pgTable("trips", {
  id: serial("id").primaryKey(),
  destination: text("destination").notNull(),
  description: text("description").notNull(),
  descriptionAr: text("description_ar"), // Arabic description
  price: integer("price").notNull(),
  imageUrl: text("image_url").notNull(),
  departureDate: timestamp("departure_date").notNull(),
  duration: integer("duration").notNull(), // in days
  cabinClass: text("cabin_class").notNull(), // economy, luxury, vip
  availableSeats: integer("available_seats").notNull(),
  vipPerks: jsonb("vip_perks"), // Array of special VIP benefits
});

export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id),
  tripId: integer("trip_id")
    .notNull()
    .references(() => trips.id),
  status: text("status").notNull(), // confirmed, pending, cancelled
  passengers: integer("passengers").notNull(),
  totalPrice: integer("total_price").notNull(),
  bookedAt: timestamp("booked_at").notNull().defaultNow(),
  conciergeAssigned: text("concierge_assigned"), // VIP concierge name
  specialRequests: text("special_requests"), // VIP special requests
});

export const hotels = pgTable("hotels", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  nameAr: text("name_ar"), // Arabic name
  description: text("description").notNull(),
  descriptionAr: text("description_ar"), // Arabic description
  location: text("location").notNull(), // orbital, lunar, mars
  price: integer("price").notNull(), // per night
  amenities: jsonb("amenities").notNull(),
  imageUrl: text("image_url").notNull(),
  rating: integer("rating").notNull(),
  vipLounge: boolean("vip_lounge").default(false),
});

// Stripe subscription integration
export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id),
  stripeCustomerId: text("stripe_customer_id").notNull(),
  stripeSubscriptionId: text("stripe_subscription_id").notNull(),
  status: text("status").notNull(), // active, canceled, past_due
  plan: text("plan").notNull(), // gold, platinum
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  language: true,
});

export const insertTripSchema = createInsertSchema(trips);
export const insertBookingSchema = createInsertSchema(bookings);
export const insertHotelSchema = createInsertSchema(hotels);
export const insertSubscriptionSchema = createInsertSchema(subscriptions);

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertTrip = z.infer<typeof insertTripSchema>;
export type InsertBooking = z.infer<typeof insertBookingSchema>;
export type InsertHotel = z.infer<typeof insertHotelSchema>;
export type InsertSubscription = z.infer<typeof insertSubscriptionSchema>;

export type User = typeof users.$inferSelect;
export type Trip = typeof trips.$inferSelect;
export type Booking = typeof bookings.$inferSelect;
export type Hotel = typeof hotels.$inferSelect;
export type Subscription = typeof subscriptions.$inferSelect;