import {
  users, trips, bookings, hotels,
  type User, type Trip, type Booking, type Hotel,
  type InsertUser, type InsertTrip, type InsertBooking, type InsertHotel
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Trips
  getTrips(): Promise<Trip[]>;
  getTrip(id: number): Promise<Trip | undefined>;
  createTrip(trip: InsertTrip): Promise<Trip>;
  updateTripSeats(id: number, seats: number): Promise<Trip>;
  
  // Bookings
  getBookings(userId: number): Promise<Booking[]>;
  getBooking(id: number): Promise<Booking | undefined>;
  createBooking(booking: InsertBooking): Promise<Booking>;
  updateBookingStatus(id: number, status: string): Promise<Booking>;
  
  // Hotels
  getHotels(): Promise<Hotel[]>;
  getHotel(id: number): Promise<Hotel | undefined>;
  createHotel(hotel: InsertHotel): Promise<Hotel>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private trips: Map<number, Trip>;
  private bookings: Map<number, Booking>;
  private hotels: Map<number, Hotel>;
  private currentIds: { [key: string]: number };

  constructor() {
    this.users = new Map();
    this.trips = new Map();
    this.bookings = new Map();
    this.hotels = new Map();
    this.currentIds = { users: 1, trips: 1, bookings: 1, hotels: 1 };
    
    // Initialize with some sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    const sampleTrips: InsertTrip[] = [
      {
        destination: "Orbital Station Alpha",
        description: "Experience luxury in low Earth orbit with breathtaking views of our planet.",
        descriptionAr: "استمتع بالفخامة في المدار الأرضي المنخفض مع إطلالات خلابة على كوكبنا.",
        price: 250000,
        imageUrl: "https://images.unsplash.com/photo-1446776709462-d6b525c57bd3",
        departureDate: new Date("2024-06-15"),
        duration: 5,
        cabinClass: "luxury",
        availableSeats: 8,
        vipPerks: ["Private Suite", "Personal Chef", "Space Walk Experience"]
      },
      {
        destination: "Lunar Resort",
        description: "Walk on the moon and stay in our exclusive lunar facilities.",
        descriptionAr: "امشِ على سطح القمر وأقم في منشآتنا الحصرية على القمر.",
        price: 500000,
        imageUrl: "https://images.unsplash.com/photo-1460186136353-977e9d6085a1",
        departureDate: new Date("2024-07-20"),
        duration: 10,
        cabinClass: "vip",
        availableSeats: 4,
        vipPerks: ["Private Lunar Vehicle", "Exclusive Crater Tour", "First Class Lounge"]
      }
    ];

    const sampleHotels: InsertHotel[] = [
      {
        name: "Celestial Suites",
        nameAr: "أجنحة سيليستيال",
        description: "Luxury accommodations in zero gravity",
        descriptionAr: "إقامة فاخرة في انعدام الجاذبية",
        location: "orbital",
        price: 50000,
        amenities: ["Zero-G Spa", "Space View Restaurant", "Artificial Gravity Chambers"],
        imageUrl: "https://images.unsplash.com/photo-1504192010706-dd7f569ee2be",
        rating: 5,
        vipLounge: true
      },
      {
        name: "Lunar Palace",
        nameAr: "قصر القمر",
        description: "Experience lunar living at its finest",
        descriptionAr: "جرب الحياة القمرية في أفضل صورها",
        location: "lunar",
        price: 75000,
        amenities: ["Moon Walk Tours", "Crater View Rooms", "Oxygen Gardens"],
        imageUrl: "https://images.unsplash.com/photo-1457364983758-510f8afa9f5f",
        rating: 5,
        vipLounge: true
      }
    ];

    sampleTrips.forEach(trip => this.createTrip(trip));
    sampleHotels.forEach(hotel => this.createHotel(hotel));
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentIds.users++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Trip methods
  async getTrips(): Promise<Trip[]> {
    return Array.from(this.trips.values());
  }

  async getTrip(id: number): Promise<Trip | undefined> {
    return this.trips.get(id);
  }

  async createTrip(insertTrip: InsertTrip): Promise<Trip> {
    const id = this.currentIds.trips++;
    const trip: Trip = { ...insertTrip, id };
    this.trips.set(id, trip);
    return trip;
  }

  async updateTripSeats(id: number, seats: number): Promise<Trip> {
    const trip = await this.getTrip(id);
    if (!trip) throw new Error("Trip not found");
    
    const updatedTrip: Trip = { ...trip, availableSeats: seats };
    this.trips.set(id, updatedTrip);
    return updatedTrip;
  }

  // Booking methods
  async getBookings(userId: number): Promise<Booking[]> {
    return Array.from(this.bookings.values()).filter(
      booking => booking.userId === userId
    );
  }

  async getBooking(id: number): Promise<Booking | undefined> {
    return this.bookings.get(id);
  }

  async createBooking(insertBooking: InsertBooking): Promise<Booking> {
    const id = this.currentIds.bookings++;
    const booking: Booking = { ...insertBooking, id };
    this.bookings.set(id, booking);
    return booking;
  }

  async updateBookingStatus(id: number, status: string): Promise<Booking> {
    const booking = await this.getBooking(id);
    if (!booking) throw new Error("Booking not found");
    
    const updatedBooking: Booking = { ...booking, status };
    this.bookings.set(id, updatedBooking);
    return updatedBooking;
  }

  // Hotel methods
  async getHotels(): Promise<Hotel[]> {
    return Array.from(this.hotels.values());
  }

  async getHotel(id: number): Promise<Hotel | undefined> {
    return this.hotels.get(id);
  }

  async createHotel(insertHotel: InsertHotel): Promise<Hotel> {
    const id = this.currentIds.hotels++;
    const hotel: Hotel = { ...insertHotel, id };
    this.hotels.set(id, hotel);
    return hotel;
  }
}

export const storage = new MemStorage();