import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Rocket, Shield, AlertTriangle, CheckCircle } from "lucide-react";

const TRAINING_MODULES = [
  {
    id: "zero-g",
    title: "Zero Gravity Adaptation",
    titleAr: "التكيف مع انعدام الجاذبية",
    description: "Learn to move and work in zero gravity environments",
    descriptionAr: "تعلم التحرك والعمل في بيئات انعدام الجاذبية",
    difficulty: "Medium",
    duration: "30 minutes",
    icon: Rocket,
  },
  {
    id: "safety",
    title: "Safety Procedures",
    titleAr: "إجراءات السلامة",
    description: "Master emergency protocols and safety measures",
    descriptionAr: "إتقان بروتوكولات الطوارئ وإجراءات السلامة",
    difficulty: "Hard",
    duration: "45 minutes",
    icon: Shield,
  },
  {
    id: "emergency",
    title: "Emergency Response",
    titleAr: "الاستجابة للطوارئ",
    description: "Practice handling space emergencies",
    descriptionAr: "التدرب على التعامل مع حالات الطوارئ في الفضاء",
    difficulty: "Expert",
    duration: "60 minutes",
    icon: AlertTriangle,
  },
];

interface SimulationState {
  oxygen: number;
  stability: number;
  pressure: number;
  temperature: number;
}

export function AstronautSimulator() {
  const [activeModule, setActiveModule] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [simulation, setSimulation] = useState<SimulationState>({
    oxygen: 100,
    stability: 100,
    pressure: 100,
    temperature: 20,
  });
  const [isTraining, setIsTraining] = useState(false);
  const [score, setScore] = useState(0);
  const [missionLog, setMissionLog] = useState<string[]>([]);

  useEffect(() => {
    if (isTraining) {
      const interval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            setIsTraining(false);
            return 100;
          }
          return prev + 1;
        });

        // Simulate environmental changes
        setSimulation((prev) => ({
          oxygen: Math.max(0, prev.oxygen + (Math.random() * 2 - 1)),
          stability: Math.max(0, prev.stability + (Math.random() * 2 - 1)),
          pressure: Math.max(0, prev.pressure + (Math.random() * 2 - 1)),
          temperature: prev.temperature + (Math.random() * 0.5 - 0.25),
        }));
      }, 100);

      return () => clearInterval(interval);
    }
  }, [isTraining]);

  const startTraining = (moduleId: string) => {
    setActiveModule(moduleId);
    setProgress(0);
    setIsTraining(true);
    setScore(0);
    setMissionLog([`Training module ${moduleId} initiated...`]);
    setSimulation({ oxygen: 100, stability: 100, pressure: 100, temperature: 20 });
  };

  const handleEmergency = () => {
    if (simulation.oxygen < 50 || simulation.stability < 50 || simulation.pressure < 50) {
      setScore((prev) => prev + 10);
      setMissionLog(prev => [...prev, "Emergency handled successfully! +10 points"]);
    } else {
      setScore((prev) => Math.max(0, prev - 5));
      setMissionLog(prev => [...prev, "False alarm! -5 points"]);
    }
  };

  return (
    <Card className="bg-black/40 backdrop-blur-sm border-primary/20">
      <CardHeader>
        <CardTitle className="text-primary flex items-center gap-2">
          <Rocket className="h-6 w-6" />
          Astronaut Training Simulator
        </CardTitle>
      </CardHeader>
      <CardContent>
        {!activeModule ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {TRAINING_MODULES.map((module) => (
              <motion.div
                key={module.id}
                whileHover={{ scale: 1.02 }}
                className="relative"
              >
                <Card className="bg-black/20 hover:bg-black/30 transition-all">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <module.icon className="h-5 w-5 text-primary" />
                      {module.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground mb-4">
                      {module.description}
                    </p>
                    <div className="flex items-center justify-between mb-4">
                      <Badge variant="outline">{module.difficulty}</Badge>
                      <span className="text-sm text-muted-foreground">
                        {module.duration}
                      </span>
                    </div>
                    <Button
                      className="w-full hover-glow"
                      onClick={() => startTraining(module.id)}
                    >
                      Start Training
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium text-primary">
                {TRAINING_MODULES.find((m) => m.id === activeModule)?.title}
              </h3>
              <Badge variant="outline">Score: {score}</Badge>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
              <div className="bg-black/20 p-4 rounded-lg">
                <div className="text-sm text-muted-foreground mb-2">Oxygen Level</div>
                <Progress value={simulation.oxygen} className="h-2" />
                <div className="text-xs text-primary mt-1">{Math.round(simulation.oxygen)}%</div>
              </div>
              <div className="bg-black/20 p-4 rounded-lg">
                <div className="text-sm text-muted-foreground mb-2">Stability</div>
                <Progress value={simulation.stability} className="h-2" />
                <div className="text-xs text-primary mt-1">{Math.round(simulation.stability)}%</div>
              </div>
              <div className="bg-black/20 p-4 rounded-lg">
                <div className="text-sm text-muted-foreground mb-2">Pressure</div>
                <Progress value={simulation.pressure} className="h-2" />
                <div className="text-xs text-primary mt-1">{Math.round(simulation.pressure)}%</div>
              </div>
              <div className="bg-black/20 p-4 rounded-lg">
                <div className="text-sm text-muted-foreground mb-2">Temperature</div>
                <Progress value={((simulation.temperature - 10) / 30) * 100} className="h-2" />
                <div className="text-xs text-primary mt-1">{simulation.temperature.toFixed(1)}°C</div>
              </div>
            </div>

            <Progress value={progress} className="h-2 mb-4" />

            <div className="bg-black/20 p-4 rounded-lg mb-4">
              <div className="text-sm text-primary mb-2">Mission Log</div>
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {missionLog.map((log, index) => (
                  <div key={index} className="text-sm text-muted-foreground">
                    {log}
                  </div>
                ))}
              </div>
            </div>

            {(simulation.oxygen < 50 || simulation.stability < 50 || simulation.pressure < 50) && (
              <Alert className="bg-red-500/20 border-red-500/50 animate-pulse">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  Emergency situation detected! Take action immediately!
                </AlertDescription>
              </Alert>
            )}

            <div className="flex gap-4">
              <Button
                variant="destructive"
                onClick={handleEmergency}
                className="flex-1"
              >
                Handle Emergency
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setActiveModule(null);
                  setIsTraining(false);
                  setMissionLog([]);
                }}
              >
                Exit Training
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}