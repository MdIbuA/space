import { useState, useEffect } from "react";
import { motion, useAnimation } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Rocket, Radio, Gauge, Wind } from "lucide-react";

interface SystemStatus {
  fuel: number;
  oxygen: number;
  pressure: number;
  temperature: number;
}

export function VRLaunchExperience() {
  const [phase, setPhase] = useState<number>(0);
  const [status, setStatus] = useState<SystemStatus>({
    fuel: 100,
    oxygen: 100,
    pressure: 100,
    temperature: 20,
  });
  const [missionLog, setMissionLog] = useState<string[]>([]);
  const controls = useAnimation();

  const LAUNCH_PHASES = [
    { name: "Pre-Launch Check", duration: 5000 },
    { name: "Engine Ignition", duration: 3000 },
    { name: "Lift Off", duration: 4000 },
    { name: "Stage Separation", duration: 3000 },
    { name: "Orbit Insertion", duration: 5000 },
  ];

  const addLog = (message: string) => {
    setMissionLog(prev => [...prev, `T${phase < 2 ? '-' : '+'}${Math.abs(phase - 2)}:00 - ${message}`]);
  };

  const startLaunch = async () => {
    setPhase(0);
    setMissionLog([]);

    for (let i = 0; i < LAUNCH_PHASES.length; i++) {
      setPhase(i);
      addLog(`Initiating ${LAUNCH_PHASES[i].name}`);

      await controls.start({
        rotateX: i === 2 ? 45 : 0,
        y: i === 2 ? -100 : 0,
        transition: { duration: LAUNCH_PHASES[i].duration / 1000 },
      });

      // Simulate system changes
      setStatus(prev => ({
        fuel: Math.max(0, prev.fuel - 20),
        oxygen: Math.max(0, prev.oxygen - 10),
        pressure: Math.max(0, prev.pressure + (i === 1 ? 20 : -10)),
        temperature: prev.temperature + (i === 1 ? 30 : 10),
      }));

      await new Promise(resolve => setTimeout(resolve, LAUNCH_PHASES[i].duration));
    }

    addLog("Launch sequence completed successfully!");
  };

  return (
    <Card className="bg-black/40 backdrop-blur-sm border-primary/20">
      <CardHeader>
        <CardTitle className="text-primary flex items-center gap-2">
          <Rocket className="h-6 w-6" />
          VR Launch Experience
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="relative perspective-1000 h-[400px] mb-6">
          <motion.div
            animate={controls}
            className="absolute inset-0 preserve-3d"
          >
            <div className="relative h-full rounded-lg overflow-hidden">
              <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1517976487492-5750f3195933')] bg-cover bg-center" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />

              {/* Cockpit UI */}
              <div className="absolute inset-0 p-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-primary">
                      <Gauge className="h-4 w-4" />
                      <span>Fuel: {status.fuel}%</span>
                    </div>
                    <Progress value={status.fuel} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-primary">
                      <Wind className="h-4 w-4" />
                      <span>Oxygen: {status.oxygen}%</span>
                    </div>
                    <Progress value={status.oxygen} className="h-2" />
                  </div>
                </div>

                <div className="absolute bottom-6 left-6 right-6">
                  <div className="bg-black/60 rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Radio className="h-4 w-4 text-primary animate-pulse" />
                      <span className="text-primary">Mission Control</span>
                    </div>
                    <div className="h-32 overflow-y-auto space-y-2">
                      {missionLog.map((log, i) => (
                        <div key={i} className="text-sm text-muted-foreground">
                          {log}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <h3 className="text-lg font-medium text-primary">
                {phase < LAUNCH_PHASES.length ? LAUNCH_PHASES[phase].name : "Launch Complete"}
              </h3>
              <p className="text-sm text-muted-foreground">
                Experience the thrill of space launch in virtual reality
              </p>
            </div>
            <Badge variant="outline">
              Temperature: {status.temperature}°C
            </Badge>
          </div>

          <Button
            className="w-full hover-glow"
            onClick={startLaunch}
            disabled={phase > 0 && phase < LAUNCH_PHASES.length}
          >
            {phase > 0 && phase < LAUNCH_PHASES.length ? "Launch Sequence in Progress..." : "Start Launch Sequence"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}