import { Container } from "@/components/ui/container";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Rocket } from "lucide-react";
import { Link } from "wouter";
import { StarfieldBackground } from "@/components/starfield-background";

export default function Home() {
  return (
    <div className="min-h-screen relative overflow-hidden bg-gradient-to-b from-black via-purple-900/20 to-black">
      <StarfieldBackground />
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm">
        <Container>
          <div className="flex flex-col items-center justify-center min-h-screen pt-16 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="max-w-3xl"
            >
              <motion.div
                initial={{ scale: 0.9 }}
                animate={{ scale: 1 }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  repeatType: "reverse"
                }}
                className="mb-8"
              >
                <Rocket className="h-16 w-16 text-primary mx-auto" />
              </motion.div>

              <h1 className="text-5xl md:text-7xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary via-purple-500 to-primary mb-6">
                Dubai to the Stars
              </h1>

              <p className="text-xl md:text-2xl text-muted-foreground mb-8 leading-relaxed">
                Experience luxury space travel from the world's first commercial
                spaceport. Your journey to the stars begins here.
              </p>

              <div className="flex gap-4 justify-center">
                <Button
                  asChild
                  size="lg"
                  className="bg-gradient-to-r from-primary to-purple-600 hover:from-primary/80 hover:to-purple-600/80 transition-all duration-300"
                >
                  <Link href="/trips">
                    <Rocket className="mr-2 h-5 w-5" />
                    Book Your Journey
                  </Link>
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  asChild
                  className="border-primary/20 hover:border-primary/40 backdrop-blur-sm"
                >
                  <Link href="/dashboard">View Dashboard</Link>
                </Button>
              </div>
            </motion.div>
          </div>
        </Container>
      </div>
    </div>
  );
}