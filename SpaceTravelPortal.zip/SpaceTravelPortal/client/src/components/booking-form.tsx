import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Trip } from "@shared/schema";
import { useState } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const bookingSchema = z.object({
  passengers: z.number().min(1).max(4),
});

type BookingFormValues = z.infer<typeof bookingSchema>;

interface BookingFormProps {
  trip: Trip;
  onSuccess: () => void;
  onCancel: () => void;
}

export function BookingForm({ trip, onSuccess, onCancel }: BookingFormProps) {
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const form = useForm<BookingFormValues>({
    resolver: zodResolver(bookingSchema),
    defaultValues: {
      passengers: 1,
    },
  });

  async function onSubmit(data: BookingFormValues) {
    setIsLoading(true);
    try {
      const booking = {
        tripId: trip.id,
        userId: 1, // In a real app, this would come from auth context
        passengers: data.passengers,
        totalPrice: trip.price * data.passengers,
        status: "confirmed",
      };

      await apiRequest("POST", "/api/bookings", booking);
      toast({
        title: "Booking Confirmed",
        description: "Your space adventure awaits!",
      });
      onSuccess();
    } catch (error) {
      toast({
        title: "Booking Failed",
        description: "Please try again later",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="passengers"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Number of Passengers</FormLabel>
              <FormControl>
                <Input
                  type="number"
                  min={1}
                  max={4}
                  {...field}
                  onChange={(e) => field.onChange(parseInt(e.target.value))}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex gap-4">
          <Button type="submit" disabled={isLoading}>
            {isLoading ? "Booking..." : "Confirm Booking"}
          </Button>
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        </div>
      </form>
    </Form>
  );
}
