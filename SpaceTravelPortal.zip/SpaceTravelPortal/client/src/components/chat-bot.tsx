import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { X, Languages, Crown } from "lucide-react";

const SAMPLE_RESPONSES = {
  "en": {
    "hello": "Hello! How can I assist you with your space travel plans today?",
    "pricing": "Our space trips start from $250,000 for orbital experiences. Would you like to know more about our packages?",
    "safety": "Safety is our top priority. All our vessels exceed international space safety standards and our crew undergoes rigorous training.",
    "vip": "Our VIP service includes a dedicated concierge, priority boarding, and exclusive access to luxury facilities. Would you like to learn more about our VIP memberships?",
    "default": "I'm here to help with any questions about our space travel services. Feel free to ask about our destinations, pricing, or safety measures."
  },
  "ar": {
    "hello": "مرحباً! كيف يمكنني مساعدتك في خطط السفر الفضائية اليوم؟",
    "pricing": "تبدأ رحلاتنا الفضائية من 250,000 دولار للتجارب المدارية. هل تريد معرفة المزيد عن باقاتنا؟",
    "safety": "السلامة هي أولويتنا القصوى. تتجاوز جميع مركباتنا معايير السلامة الدولية ويخضع طاقمنا لتدريب صارم.",
    "vip": "تتضمن خدمة كبار الشخصيات لدينا كونسيرج مخصص، وأولوية الصعود، وحق الوصول الحصري إلى المرافق الفاخرة. هل تريد معرفة المزيد عن عضويات كبار الشخصيات لدينا؟",
    "default": "أنا هنا للمساعدة في أي أسئلة حول خدمات السفر الفضائي لدينا. لا تتردد في السؤال عن وجهاتنا وأسعارنا أو إجراءات السلامة."
  }
};

const VIP_CONCIERGE_RESPONSES = {
  "en": {
    "greeting": "Welcome to our VIP Concierge Service. I'm your personal space travel assistant. How may I enhance your journey today?",
    "custom": "I'll make all necessary arrangements for your custom requests. Would you like me to coordinate anything specific for your journey?",
    "upgrade": "I can help you upgrade to our luxury accommodations. Would you like to see our premium suite options?",
  },
  "ar": {
    "greeting": "مرحباً بكم في خدمة الكونسيرج لكبار الشخصيات. أنا مساعدك الشخصي للسفر الفضائي. كيف يمكنني تحسين رحلتك اليوم؟",
    "custom": "سأقوم بجميع الترتيبات اللازمة لطلباتك الخاصة. هل تريد مني تنسيق أي شيء محدد لرحلتك؟",
    "upgrade": "يمكنني مساعدتك في الترقية إلى أماكن إقامتنا الفاخرة. هل تريد رؤية خيارات الأجنحة الفاخرة لدينا؟",
  }
};

export function ChatBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ text: string; isUser: boolean }[]>([
    { text: "Hi! I'm your Space Travel Assistant. How can I help you today?", isUser: false }
  ]);
  const [input, setInput] = useState("");
  const [language, setLanguage] = useState<"en" | "ar">("en");
  const [isVIP, setIsVIP] = useState(false);

  useEffect(() => {
    const handleToggle = () => setIsOpen(prev => !prev);
    window.addEventListener('toggle-chat', handleToggle);
    return () => window.removeEventListener('toggle-chat', handleToggle);
  }, []);

  const handleSend = () => {
    if (!input.trim()) return;

    setMessages(prev => [...prev, { text: input, isUser: true }]);

    // Simple response logic
    let response;
    if (isVIP) {
      response = Object.entries(VIP_CONCIERGE_RESPONSES[language]).find(([key]) => 
        input.toLowerCase().includes(key))?.[1] || SAMPLE_RESPONSES[language].default;
    } else {
      response = Object.entries(SAMPLE_RESPONSES[language]).find(([key]) => 
        input.toLowerCase().includes(key))?.[1] || SAMPLE_RESPONSES[language].default;
    }

    setTimeout(() => {
      setMessages(prev => [...prev, { text: response, isUser: false }]);
    }, 500);

    setInput("");
  };

  const toggleLanguage = () => {
    const newLang = language === "en" ? "ar" : "en";
    setLanguage(newLang);
    // Update initial greeting in new language
    setMessages([{ text: SAMPLE_RESPONSES[newLang].hello, isUser: false }]);
  };

  const toggleVIP = () => {
    setIsVIP(!isVIP);
    // Update greeting for VIP mode
    if (!isVIP) {
      setMessages([{ text: VIP_CONCIERGE_RESPONSES[language].greeting, isUser: false }]);
    }
  };

  if (!isOpen) return null;

  return (
    <Card className="fixed bottom-4 right-4 w-80 bg-black/40 backdrop-blur-sm border-primary/20 z-50">
      <CardHeader className="flex flex-row items-center justify-between p-4">
        <CardTitle className="text-primary text-sm">
          {isVIP ? "VIP Concierge" : "AI Space Assistant"}
        </CardTitle>
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleLanguage}
            className="h-8 w-8 p-0"
          >
            <Languages className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleVIP}
            className="h-8 w-8 p-0"
          >
            <Crown className={`h-4 w-4 ${isVIP ? "text-primary" : ""}`} />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsOpen(false)}
            className="h-8 w-8 p-0"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <ScrollArea className="h-[300px] mb-4" dir={language === "ar" ? "rtl" : "ltr"}>
          <div className="space-y-4">
            {messages.map((message, i) => (
              <div
                key={i}
                className={`flex ${message.isUser ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`rounded-lg px-3 py-2 max-w-[80%] ${
                    message.isUser
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted"
                  }`}
                >
                  {message.text}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
        <div className="flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleSend()}
            placeholder={language === "en" ? "Type your message..." : "اكتب رسالتك..."}
            className="bg-muted"
            dir={language === "ar" ? "rtl" : "ltr"}
          />
          <Button onClick={handleSend}>
            {language === "en" ? "Send" : "إرسال"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}