import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Container } from "@/components/ui/container";
import { TripCard } from "@/components/trip-card";
import { BookingForm } from "@/components/booking-form";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Trip } from "@shared/schema";
import { motion } from "framer-motion";

export default function Trips() {
  const [selectedTrip, setSelectedTrip] = useState<Trip | null>(null);

  const { data: trips, isLoading } = useQuery({
    queryKey: ["/api/trips"],
  });

  if (isLoading) {
    return (
      <Container className="py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              className="h-[400px] bg-black/40 animate-pulse rounded-lg"
            />
          ))}
        </div>
      </Container>
    );
  }

  return (
    <div className="min-h-screen bg-[url('https://images.unsplash.com/photo-1676822946700-b6f9a447774c')] bg-cover bg-fixed">
      <div className="min-h-screen bg-black/60 backdrop-blur-sm py-12">
        <Container>
          <motion.h1
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl font-bold text-primary mb-8"
          >
            Available Space Journeys
          </motion.h1>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {trips?.map((trip: Trip) => (
              <TripCard
                key={trip.id}
                trip={trip}
                onBook={() => setSelectedTrip(trip)}
              />
            ))}
          </div>

          <Dialog open={!!selectedTrip} onOpenChange={() => setSelectedTrip(null)}>
            <DialogContent>
              {selectedTrip && (
                <BookingForm
                  trip={selectedTrip}
                  onSuccess={() => setSelectedTrip(null)}
                  onCancel={() => setSelectedTrip(null)}
                />
              )}
            </DialogContent>
          </Dialog>
        </Container>
      </div>
    </div>
  );
}
