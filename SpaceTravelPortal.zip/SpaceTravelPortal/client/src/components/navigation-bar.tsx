import { Link, useLocation } from "wouter";
import { Container } from "@/components/ui/container";
import { Button } from "@/components/ui/button";
import { Rocket, Phone, MessageSquare } from "lucide-react";

export function NavigationBar() {
  const [location] = useLocation();

  return (
    <div className="fixed top-0 left-0 right-0 z-50 bg-black/40 backdrop-blur-sm border-b border-primary/20">
      <Container>
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2">
            <Rocket className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold text-primary hover-glow">Dubai to the Stars</span>
          </Link>

          <div className="flex items-center gap-6">
            <Link href="/dashboard" 
              className={`text-sm hover-glow ${
                location === "/dashboard" ? "text-primary" : "text-muted-foreground"
              }`}>
              Dashboard
            </Link>
            <Link href="/trips"
              className={`text-sm hover-glow ${
                location === "/trips" ? "text-primary" : "text-muted-foreground"
              }`}>
              Book Trips
            </Link>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Phone className="h-4 w-4" />
              <span>+971 800 SPACE</span>
            </div>
            <Button 
              variant="outline" 
              size="sm"
              className="gap-2 border-primary/20"
              onClick={() => window.dispatchEvent(new CustomEvent('toggle-chat'))}>
              <MessageSquare className="h-4 w-4" />
              AI Assistant
            </Button>
          </div>
        </div>
      </Container>
    </div>
  );
}
