import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Crown, Star, Shield, CheckCircle } from "lucide-react";
import { motion } from "framer-motion";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const VIP_PLANS = [
  {
    name: "Gold",
    icon: Star,
    price: 5000,
    features: [
      "Priority Booking",
      "VIP Lounge Access",
      "Dedicated Concierge",
      "Complimentary Upgrades"
    ]
  },
  {
    name: "Platinum",
    icon: Crown,
    price: 10000,
    features: [
      "All Gold Benefits",
      "Private Space Walks",
      "Luxury Suite Guarantee",
      "Personal Chef in Space",
      "Custom Flight Schedule"
    ]
  }
];

export function VIPMembership() {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const handleUpgrade = async (plan: string) => {
    setIsProcessing(true);
    try {
      // In a real app, this would create a Stripe payment intent
      await apiRequest("POST", "/api/create-payment-intent", {
        amount: VIP_PLANS.find(p => p.name === plan)?.price,
        plan: plan
      });

      toast({
        title: "Upgrade Initiated",
        description: "Please complete the payment process to activate your VIP membership.",
      });
      setSelectedPlan(plan);
    } catch (error) {
      toast({
        title: "Upgrade Failed",
        description: "Please try again later or contact support.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="grid md:grid-cols-2 gap-6">
      {VIP_PLANS.map((plan) => {
        const Icon = plan.icon;
        const isSelected = selectedPlan === plan.name;

        return (
          <motion.div
            key={plan.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            whileHover={{ scale: 1.02 }}
          >
            <Card className={`backdrop-blur-sm border-primary/20 overflow-hidden relative
              ${isSelected ? 'bg-primary/10' : 'bg-black/40'}`}>
              {isSelected && (
                <div className="absolute top-2 right-2">
                  <CheckCircle className="h-6 w-6 text-primary" />
                </div>
              )}
              <CardHeader className="space-y-1">
                <div className="flex items-center gap-2">
                  <Icon className="h-6 w-6 text-primary" />
                  <CardTitle className="text-2xl text-primary">{plan.name} Membership</CardTitle>
                </div>
                <div className="text-3xl font-bold text-primary">
                  ${plan.price.toLocaleString()}/year
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-4">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-center gap-2">
                      <Shield className="h-4 w-4 text-primary" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <Button 
                  className="w-full mt-6 hover-glow"
                  onClick={() => handleUpgrade(plan.name)}
                  disabled={isProcessing}
                >
                  {isProcessing ? (
                    <div className="flex items-center gap-2">
                      <div className="animate-spin h-4 w-4 border-2 border-primary border-t-transparent rounded-full" />
                      Processing...
                    </div>
                  ) : (
                    `Upgrade to ${plan.name}`
                  )}
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        );
      })}
    </div>
  );
}