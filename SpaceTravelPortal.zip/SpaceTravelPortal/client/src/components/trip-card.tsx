import { useState } from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trip } from "@shared/schema";
import { format } from "date-fns";
import { Crown, Star, Eye } from "lucide-react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { HolographicPreview } from "./holographic-preview";

interface TripCardProps {
  trip: Trip;
  onBook: (trip: Trip) => void;
}

export function TripCard({ trip, onBook }: TripCardProps) {
  const [showPreview, setShowPreview] = useState(false);
  const isVIP = trip.cabinClass === "vip";

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        whileHover={{ scale: 1.02 }}
      >
        <Card className="overflow-hidden bg-black/40 backdrop-blur-sm border-primary/20 relative">
          {isVIP && (
            <div className="absolute top-2 right-2 z-10">
              <Crown className="h-6 w-6 text-primary animate-pulse" />
            </div>
          )}
          <div className="relative h-48">
            <img
              src={trip.imageUrl}
              alt={trip.destination}
              className="absolute inset-0 w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            <Button
              variant="ghost"
              size="sm"
              className="absolute top-2 left-2 bg-black/20 hover:bg-black/40"
              onClick={() => setShowPreview(true)}
            >
              <Eye className="h-4 w-4 mr-2" />
              Holographic Preview
            </Button>
          </div>
          <CardHeader>
            <CardTitle className="text-xl text-primary flex items-center gap-2">
              {trip.destination}
              {trip.vipPerks && trip.vipPerks.length > 0 && (
                <Star className="h-4 w-4 text-primary" />
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-4">{trip.description}</p>
            {trip.descriptionAr && (
              <p className="text-muted-foreground mb-4 text-right" dir="rtl">
                {trip.descriptionAr}
              </p>
            )}
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>Departure</span>
                <span className="text-primary">
                  {format(new Date(trip.departureDate), "PPP")}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Duration</span>
                <span className="text-primary">{trip.duration} days</span>
              </div>
              <div className="flex justify-between">
                <span>Class</span>
                <span className="text-primary capitalize">{trip.cabinClass}</span>
              </div>
              <div className="flex justify-between">
                <span>Available Seats</span>
                <span className="text-primary">{trip.availableSeats}</span>
              </div>
            </div>
            {trip.vipPerks && trip.vipPerks.length > 0 && (
              <div className="mt-4 p-3 bg-primary/5 rounded-lg border border-primary/10">
                <h4 className="text-sm font-medium text-primary mb-2">VIP Perks</h4>
                <ul className="space-y-1">
                  {trip.vipPerks.map((perk, index) => (
                    <li key={index} className="text-sm text-muted-foreground flex items-center gap-2">
                      <Star className="h-3 w-3 text-primary" />
                      {perk}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
          <CardFooter className="flex justify-between items-center">
            <div className="text-2xl font-bold text-primary">
              ${trip.price.toLocaleString()}
            </div>
            <Button 
              onClick={() => onBook(trip)}
              className={`hover-glow ${isVIP ? 'bg-gradient-to-r from-primary to-purple-600' : ''}`}
            >
              Book Now
            </Button>
          </CardFooter>
        </Card>
      </motion.div>

      <Dialog open={showPreview} onOpenChange={setShowPreview}>
        <DialogContent className="max-w-4xl bg-transparent border-none">
          <HolographicPreview trip={trip} />
        </DialogContent>
      </Dialog>
    </>
  );
}